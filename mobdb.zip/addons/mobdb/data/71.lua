--Zone: The Colosseum
--Zone ID: 71
return {
};